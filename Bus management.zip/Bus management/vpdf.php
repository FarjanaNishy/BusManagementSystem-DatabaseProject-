﻿<!DOCTYPE html>
<html>
<head>
<title style="font-size:20px;"> RESTAURANT DATABASE </title>
<link type="text/css" rel="stylesheet"href="css/style1.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<style>
.table{
	padding:10px;
margin:110px;
}

table, th, td {
     border: 1px solid black;
	 width:1000px;
	 text-align:center;
	
}
p{
	font-family:helvatica;
	font-size:50px;
}
</style>

</head>

<body>

<h1> RESTAURANT DATABASE MANAGEMENT </h1>
<div class="menu">
<ul>
<li><a href="home_page.php">Home</a></li>
<li><a href="search.html">search</a></li>
<li><a href="employee.html">Insert</a></li>
<li><a href="view.php">View</a></li>
<li><a href="test.php">update</a>
</ul></div>
<div class="table"><div id="printableArea">
<h2 align="center"> Employee Data Set </h2>
<table border="1" align="center">
	
			<?php
			include("db.php");
			echo "<table ><tr><th>Customer ID</th><th>Customer Name</th><th>Gender</th><th>Contact No</th><th>Address</th><th>Shift</th><th>Salary</th></tr>";
			
				
			$result=mysql_query("SELECT * FROM employee_information");
			
			while($test= mysql_fetch_array($result))
			{
				$id = $test['id'];	
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$test['id']."</font></td>";
				echo"<td><font color='black'>" .$test['name']."</font></td>";
				echo"<td><font color='black'>" .$test['department']. "</font></td>";
				echo"<td><font color='black'>" .$test['address']. "</font></td>";
				echo"<td><font color='black'>" .$test['contact']. "</font></td>";	
									
				echo "</tr>";
			}
			mysql_close($conn);
			?>
</table></div>
<input type="button" onclick="printDiv('printableArea')" value="print a div!" />
<div class="footer"> 

<script>
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}</script>
</body>
</html>
