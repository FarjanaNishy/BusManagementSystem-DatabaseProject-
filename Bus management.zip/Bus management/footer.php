  
<!DOCTYPE html>
<html>

<head>
  <style>
  div.container {
    width: 100%;
    border: 0px solid gray;
    height: 30px;
               }
    header {
    padding: 10px;
    color: green;
    background-color: lightblue;
    clear: left;
    text-align: center;
                  }
    footer{
    padding: 8px;
    color: green;
    background-color: lightblue;
    clear: left;
    text-align: center;
    }
    
    a:link{
      color: gray;
      text-decoration: none;
    }
    a:visited{
      color: red;
      text-decoration: none;
    }
.navbar {
    overflow: hidden;
    background-color: #3B5998;
    font-family: Arial;

}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 80px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 110px;
    background-color: inherit;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color:cornflowerblue ;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 120px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 8px 80px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}
 </style>


</head>



  <footer>
    <font size="5"><i><b>Developed By:</b><br>
    
  Farjana Ema Nishy <br>
  ID: 18103248
  
	</i></font>

  </footer>

  </html>
