<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "bus";

$conn = new mysqli($hostname,$username,$password,$dbname);



if($conn->connect_error) {
    die("Connection Fail".$conn->connect_error);
}
?>