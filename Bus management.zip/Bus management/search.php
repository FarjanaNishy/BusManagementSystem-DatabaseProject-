<!DOCTYPE html>
<html lang="en">
<head>
<title style="font-size:20px;"> Bus Scheduling Management System of IUBAT </title>
<link type="text/css" rel="stylesheet" href="css/style1.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<style>
.table{
    padding:10px;
margin:110px;
}

table, th, td {
     border: 1px solid black;
     width:1000px;
     text-align:center;
    
}
p{
    font-family:helvatica;
    font-size:50px;
}
header {
    padding: 10px;
    color: green;
    background-color: lightblue;
    clear: left;
    text-align: center;
                  }
    footer{
    padding: 8px;
    color: green;
    background-color: lightblue;
    clear: left;
    text-align: center;
    }
    
    a:link{
      color: gray;
      text-decoration: none;
    }
    a:visited{
      color: red;
      text-decoration: none;
    }
.navbar {
    overflow: hidden;
    background-color: #3B5998;
    font-family: Arial;

}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 110px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 110px;
    background-color: inherit;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color:cornflowerblue ;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 80px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
</style>

</head>


<body>
<header style="color: green;">
    <h1 style= "font-size:50px;" ><u>Bus Scheduling Management System of IUBAT</u></h1>
  </header>
  

<div style="padding: 140px;background-color: #30ADBE">
<center>
<form method="POST" style="text-align:center" action="search_connect.php">
<h1>Bus Information Search Form</h1>
<font size="4">Search By Bus Number:</font><br><br>
<input name="search_id" type="text"><br>
<br>

<input value="Search" type="submit">
</form>

</center>
</div>


<footer>
  <font size="6"><i><b>Developed By:</b><br>
  
  Farjana Ema Nishy <br>
  ID: 18103248
  
  </i></font>

</footer>

</body>
</html>
