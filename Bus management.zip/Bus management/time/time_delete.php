<?php 
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "bus";

$conn = new mysqli($hostname,$username,$password,$dbname);
if($conn->connect_error) {
		    die("Connection Fail".$conn->connect_error);
		}
		$id = $_GET["id"];
$sql = "DELETE FROM `tb_time` WHERE `tb_time`.`	departure_time` = '$id'";
if ($conn->query($sql) == TRUE) {
    header('Location: time_view.php');
} else {
         echo "<center><h2>Problem To DELETE</h2></center>";
}

?>