<?php 
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "bus";

$conn = new mysqli($hostname,$username,$password,$dbname);
if($conn->connect_error) {
		    die("Connection Fail".$conn->connect_error);
		}
		$id = $_GET["id"];
$sql = "DELETE FROM `tb_road` WHERE `tb_road`.`road_number` = '$id'";
if ($conn->query($sql) == TRUE) {
    header('Location: road_view.php');
} else {
         echo "<center><h2>Problem To DELETE</h2></center>";
}

?>