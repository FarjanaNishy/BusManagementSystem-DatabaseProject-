<?php 
	
	if(isset($_POST['update'])){
		$hostname = "localhost";
		$username = "root";
		$password = "";
		$dbname = "bus";

		$conn = new mysqli($hostname,$username,$password,$dbname);



		if($conn->connect_error) {
		    die("Connection Fail".$conn->connect_error);
		}


		$road_number = $_POST['roadnumber'];
		$road_name = $_POST['roadname'];
		$bus_number = $_POST['busnumber'];



		$sql = "UPDATE `tb_road` SET `road_name` = '$road_name', `associate_bus_no` = '$bus_number' WHERE `tb_road`.`road_number` = '$road_number'";

		if ($conn->query($sql) == TRUE) {
		     header('Location: road_view.php');
		} else {
		    echo "<center><h2>There is a problem to Update!!</h2></center>";
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div style="padding: 50px;  background-color: darkcyan">
	<center>
		<h2 style="font-size: 35px;">Road Information Update</h2>
		<?php
		$id = $_GET["id"];
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "bus";

          // Create connection
          $conn = mysqli_connect($servername, $username, $password, $dbname);
          // Check connection
          if (!$conn) {
              die("Connection failed: " . mysqli_connect_error());
          }

          $sql = "SELECT * FROM tb_road WHERE `road_number` = '$id'";
          $result = mysqli_query($conn, $sql);

          if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
          ?>
			<form action="" method="post">
			  Road Number<br>
			  <input type="text" name="roadnumber" value="<?php echo $row['road_number']?>" readonly="">
			  <br><br>
			  Road Name<br>
			  <input type="text" name="roadname" value="<?php echo $row['road_name']?>">
			  <br><br>
			  Associate Bus No<br>
			  <input type="text" name="busnumber" value="<?php echo $row['associate_bus_no']?>">
			  <br><br>
			  <input type="submit" value="Update" name="update">
			  <br><br>
			</form>
	</center>
	<?php
}
}
	mysqli_close($conn);
          ?>
</div>

</body>
</html>
