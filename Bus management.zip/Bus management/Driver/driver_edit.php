<?php 
	
	if(isset($_POST['update'])){
		$hostname = "localhost";
		$username = "root";
		$password = "";
		$dbname = "bus";

		$conn = new mysqli($hostname,$username,$password,$dbname);



		if($conn->connect_error) {
		    die("Connection Fail".$conn->connect_error);
		}


		$driverid = $_POST['driverid'];
		$drivername = $_POST['drivername'];
		$drivercontact = $_POST['drivercontact'];
		$driveraddress = $_POST['driveraddress'];


		$sql = "UPDATE `tb_driver` SET `driver_name` = '$drivername', `driver_contact` = '$drivercontact', `driver_address` = '$driveraddress' WHERE `tb_driver`.`driver_id` = '$driverid'";

		if ($conn->query($sql) == TRUE) {
		     header('Location: driver_view.php');
		} else {
		    echo "<center><h2>There is a problem to Update!!</h2></center>";
		}
	}
?>
<!DOCTYPE html>
<html>
<head>		
	<title></title>
</head>
<body>
	<div style="padding: 30px;  background-color: lightseagreen">
	<center>
		<h2 style="font-size: 35px;">Driver Information Update</h2>
		<?php
		$id = $_GET["id"];
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "bus";

          // Create connection
          $conn = mysqli_connect($servername, $username, $password, $dbname);
          // Check connection
          if (!$conn) {
              die("Connection failed: " . mysqli_connect_error());
          }

          $sql = "SELECT * FROM tb_driver WHERE `driver_id` = '$id'";
          $result = mysqli_query($conn, $sql);

          if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
          ?>
			<form action="" method="post">
			  Driver ID<br>
			  <input type="text" name="driverid" value="<?php echo $row['driver_id']?>" readonly="">
			  <br><br>
			  Driver Name<br>
			  <input type="text" name="drivername" value="<?php echo $row['driver_name']?>">
			  <br><br>
			  Driver Contact<br>
			  <input type="text" name="drivercontact" value="<?php echo $row['driver_contact']?>">
			  <br><br>
			  Driver Address<br>
			  <input type="text" name="driveraddress" value="<?php echo $row['driver_address']?>">
			  <br><br>
			  <input type="submit" value="Update" name="update">
			   <br><br>
			</form>
	</center>
	<?php
}
}
	mysqli_close($conn);
          ?>
</div>

</body>
</html>
