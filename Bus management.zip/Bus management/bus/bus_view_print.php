<!DOCTYPE html>
<html>
<head>
<title style="font-size:20px;"> Bus Scheduling Management System of IUBAT </title>
<link type="text/css" rel="stylesheet" href="css/style1.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<style>

div.container {
    width: 100%;
    border: 0px solid gray;
    height: 30px;
               }
.table{
	padding:10px;
margin:110px;
}

table, th, td {
     border: 1px solid black;
	 width:1000px;
	 text-align:center;
	
}
p{
	font-family:helvatica;
	font-size:50px;
}
header {
    padding: 10px;
    color: green;
    background-color: lightblue;
    clear: left;
    text-align: center;
                  }
    footer{
    padding: 8px;
    color: green;
    background-color: lightblue;
    clear: left;
    text-align: center;
    }
    
    a:link{
      color: blue;
      text-decoration: none;
    }
    a:visited{
      color: blue;
      text-decoration: none;
    }
.navbar {
    overflow: hidden;
    background-color: #3B5998;
    font-family: Arial;

}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 110px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 110px;
    background-color: inherit;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color:cornflowerblue ;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 80px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
</style>

</head>

<body>
<div class="container">
  <header style="color: green;">
    <h1 style= "font-size:50px;" ><u>Bus Scheduling Management System of IUBAT</u></h1>
  </header>
  <div class="navbar">
    <a href="home_page.php">Home</a>
    <div class="dropdown">
      <button class="dropbtn">Insert 
       <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="Bus/tb_bus.php" >Bus Info</a>
        <a href="Driver/tb_driver.php" >Driver Info</a>
        <a href="Road/tb_road.php" >Road Info</a>
        <a href="Time/tb_time.php" >Time</a>
      </div>
    </div>
    <div class="dropdown">
      <button class="dropbtn">View 
       <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="Bus/bus_view.php" >Bus Info</a>
        <a href="Driver/driver_view.php" >Driver Info</a>
        <a href="Road/road_view.php" >Road Info</a>
        <a href="Time/time_view.php" >Time</a>
      </div>
    </div> 
      <a href="search.php">Search</a>
      <a href="home_page.php">PDF</a>
  </div>


  <div style="background-color: gray;padding: 9px ;border: 0px;">
    <div class="table" >
      <div id="printableArea">
        <h2 align="center"> Bus Information Set </h2>
        <table border="1" align="center">
    	
          <?php
          $id = $_GET["id"];
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "bus";

          // Create connection
          $conn = mysqli_connect($servername, $username, $password, $dbname);
          // Check connection
          if (!$conn) {
              die("Connection failed: " . mysqli_connect_error());
          }

          $sql = "SELECT * FROM tb_bus WHERE `bus_number` = '$id'";
          $result = mysqli_query($conn, $sql);

          if ($result->num_rows > 0) {
              echo "<table align=center><tr><th>Bus Number</th><th>Departure Time</th><th>Arrival Time</th><th>No of Seat</th></tr>";
              // output data of each row
              while($row = $result->fetch_assoc()) {
                  echo "<tr><td>" . $row["bus_number"]. "</td><td>" . $row["departure_time"]."</td><td>".$row["arrival_time"]."</td><td>".$row["number_of_seat"]."</td></tr>";

              }
              echo "</table>";
          }
          else {
              echo "0 results";
          }

          mysqli_close($conn);
          ?>
        </table>
      </div>

      <br><br>
      <center><input type="button" onclick="printDiv('printableArea')" value="Print" /></center>

      <script>
      function printDiv(divName) {
          var printContents = document.getElementById(divName).innerHTML;
          var originalContents = document.body.innerHTML;
          document.body.innerHTML = printContents;
          window.print();
          document.body.innerHTML = originalContents;
      }
    </script>
    </div>
  </div>
  <footer>
    <font size="5"><i><b>Developed By:</b><br>
  Farjana Ema Nishy <br>
  ID: 18103248
	</i></font>

  </footer>
</div>
</body>
</html>

