<!DOCTYPE html>
<html>
<head>
  <style>
  div.container {
    width: 100%;
    border: 0px solid gray;
    height: 30px;
               }
    header {
    padding: 30px;
    color: darkcyan;
    background-color: lightblue;
    clear: left;
    text-align: center;
                  }
    footer{
    padding: 8px;
    color: darkcyan;
    background-color: lightblue;
    clear: left;
    text-align: center;
    }
    
    a:link{
      color: gray;
      text-decoration: none;
    }
    a:visited{
      color: red;
      text-decoration: none;
    }
.navbar {
    overflow: hidden;
    background-color: #3B5998;
    font-family: Arial;

}

.navbar a {
    float: left;
    font-size: 16px;
    color: white;
    text-align: center;
    padding: 14px 110px;
    text-decoration: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 16px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 110px;
    background-color: inherit;
}

.navbar a:hover, .dropdown:hover .dropbtn {
    background-color:cornflowerblue ;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 80px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {
    background-color: #ddd;
}

.dropdown:hover .dropdown-content {
    display: block;
}
 </style>


</head>

<body>
  <div class="container">

<header ><h1 style= "font-size:40px;">Bus Scheduling Management System of IUBAT</h1></header>

<div style="padding: 30px;  background-color: steelblue">
<center>
<h2 style="font-size: 35px;">Bus Information</h2>
<form action="bus_insert.php" method="post">
  Bus Number<br>
  <input type="text" name="busnumber">
  <br><br>
  Departure Time<br>
  <input type="text" name="dtime">
  <br><br>
  Arrival Time<br>
  <input type="text" name="atime">
  <br><br>
  Number of Seat<br>
  <input type="text" name="numberofseat">
  <br><br>
  <input type="submit" value="Submit">
</form>



</center>


<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "bus";

$conn = new mysqli($hostname,$username,$password,$dbname);



if($conn->connect_error) {
    die("Connection Fail".$conn->connect_error);
}


$bus_number = $_POST['busnumber'];
$departure_time = $_POST['dtime'];
$arrival_time = $_POST['atime'];
$seat_number = $_POST['numberofseat'];


$sql = "INSERT INTO tb_bus( bus_number,departure_time, arrival_time, number_of_seat) VALUES('$bus_number', '$departure_time','$arrival_time','$seat_number')";

if ($conn->query($sql) == TRUE) {
    echo "<center><h2>Your Information Saved successfully</h2></center>";
} else {
    if ($bus_number == "" || $departure_time == "" || $arrival_time == "" || $seat_number == "") {
         echo "<center><h2>Please input your values! </h2></center>";
    }else {
         echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

?>

</div>
<footer>
  <font size="6"><i><b>Developed By:</b><br>
 
  Farjana Ema Nishy <br>
  ID: 18103248
  
  </i></font>

</footer>
</div>
</body>
</html>