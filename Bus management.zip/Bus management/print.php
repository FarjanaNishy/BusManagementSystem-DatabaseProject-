<?php include("config.php")?>

<div class="print" id="printableArea"><br>
<h2>Book Information Table</h2>
<?php
$sql = "SELECT book_id, book_name,book_writer,book_volume,date_of_borrow,date_of_return FROM tb_book";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	
    echo "<center><table border='1' cellpadding='5'>";
	echo"<tr><th>Book ID</th><th>Book Name</th><th>Book Writer</th><th>Book Volume</th><th>Date of Borrow</th><th>Date of Return</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<center><tr ><td>".$row["book_id"]."</td><td>".$row["book_name"]."</td><td>".$row["book_writer"]."</td><td>".$row["book_volume"]."</td><td>".$row["date_of_borrow"]."</td>
		 <td>".$row["date_of_return"]."</td></tr></center>";
    }
  echo "</table></center>";
} else {
    echo "0 results";
}
$conn->close();
?>
</div><input type="submit" onclick="printDiv('printableArea')" value="Print" style="margin-left:35%"/></center>
<script>
function printDiv(divName) {
    var printContents = document.getElementById(divName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}</script>
<?php
	include("footer.php");
?>